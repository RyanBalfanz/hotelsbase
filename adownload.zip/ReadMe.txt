Hotelsbase is the world largest hotel database, available free. All we require is a link back to hotelsbase.org. 

The simplest way to get set up is by uploading our example to your site, and customising the look and feel as you see fit. 
Contained in this file is a CSV and SQL file. You can view the full hotel data at http://www.hotelsbase.org/view.php?id=[hotelId]

Please contact us at contact@hotelsbase.org if you require:
 Access to the full contact data (some such as e-mail and phone has been redacted)
 Over 10,000 API calls /day
 A SLA
 Any help setting up!
There is also a forum at http://forum.hotelsbase.org


Facilities.txt maps the facilities numbers to their words. For example, 1 indicates the first line of Facilities.txt

The propertyType field is mapped as follows:
 0 - Hotel
 1 - Motel
 2 - Inn
 3 - Bed & Breakfast
 4 - Vacation Rental
 5 - Hostel
 6 - Retreat
 7 - Resort
 8 - Other
 9 - Apartment


Hotelsbase is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License. This means you can use the data, but must link back to hotelsbase.org.
These files are provided with no warranty of any kind, and use is at your own risk.  